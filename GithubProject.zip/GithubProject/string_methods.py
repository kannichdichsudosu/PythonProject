course = "Python for Beginners"
print(course)
print(len(course))
print(course.upper())
print(course.lower())
print(course.title())
print(course.find("o")) #output the index
print(course.replace("Beginners", "Absolute Beginners")) #replace
print("Python" in course) #find if exist