first_name = "Rui"
last_name = "Lopes"

msg = f'{first_name} [{last_name}] is a coder'

print(msg)

#Rui [Lopes] is a coder