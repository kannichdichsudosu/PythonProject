birth_year = input("Birth year: ")
print(type(birth_year))
age = 2022 - int(birth_year) #convert to int
print(type(age))
print(age)

