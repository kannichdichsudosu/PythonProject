course = "Python's is for Beginners"
print(course)
print(course[0:3]) #prints index 0 until 3

course1 = '''
Hi Rui
Thank you and enjoy 3 couts to write a good text
'''
print(course1)