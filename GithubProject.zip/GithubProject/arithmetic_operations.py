print(10 / 3) #print decimal number
print(10 // 3) #print int number
print(10 % 3) #ex 10 // 3 = 3 R 1
print(10 ** 3) #expoente

x = 10
x = x + 3
print(x)#incremet a number